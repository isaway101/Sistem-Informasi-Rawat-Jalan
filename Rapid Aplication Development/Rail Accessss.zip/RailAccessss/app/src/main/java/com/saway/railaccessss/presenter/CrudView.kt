package com.saway.railaccessss.presenter

import com.saway.railaccessss.model.DataItem
import com.saway.railaccessss.model.DataSaldo

interface CrudView {
    fun onSuccessGet(data: List<DataItem>?)
    fun onFailedGet(msg : String)

    fun onSaldoGet(data: List<DataSaldo>?)
    fun onFailedSaldo(msg : String)

    fun successAdd(msg : String)
    fun errorAdd(msg: String)

    fun onSuccessUpdate(msg : String)
    fun onErrorUpdate(msg : String)

}