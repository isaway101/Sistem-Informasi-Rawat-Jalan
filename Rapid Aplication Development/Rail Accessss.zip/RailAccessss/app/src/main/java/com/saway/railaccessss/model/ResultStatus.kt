package com.saway.railaccessss.model

class ResultStatus {
    val pesan : String? = null
    val status : Int? = null
}