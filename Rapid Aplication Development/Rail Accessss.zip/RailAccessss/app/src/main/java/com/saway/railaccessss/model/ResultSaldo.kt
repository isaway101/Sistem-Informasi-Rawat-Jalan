package com.saway.railaccessss.model

import com.google.gson.annotations.SerializedName

data class ResultSaldo (
    @field:SerializedName("pesan")
    val pesan : String? = null,

    @field:SerializedName("data")
    val saldo : List<DataSaldo>? = null,

    @field:SerializedName("status")
    val status : Int? = null
)