package com.saway.railaccessss.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import com.saway.railaccessss.R

class FragmentAkun : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        (activity as AppCompatActivity).supportActionBar?.title = "Akun"
        return inflater.inflate(R.layout.fragment_akun, container, false)
    }

    companion object {
        fun newInstance(): FragmentAkun{
            val fragment = FragmentAkun()
            val args = Bundle()
            fragment.arguments = args
            return fragment
        }
    }
}