package com.saway.railaccessss.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import android.content.res.ColorStateList
import android.location.GnssAntennaInfo
import android.media.audiofx.Visualizer
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat.getColor
import com.saway.railaccessss.BookActivity
import com.saway.railaccessss.R
import com.saway.railaccessss.TiketActivity
import com.saway.railaccessss.model.DataItem
import com.saway.railaccessss.model.DataSaldo
import com.saway.railaccessss.presenter.CrudView
import com.saway.railaccessss.presenter.Presenter
import kotlinx.android.synthetic.main.fragment_booking.*
import kotlinx.android.synthetic.main.fragment_booking.view.*
import org.jetbrains.anko.sdk27.coroutines.onClick
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*


class FragmentBooking : Fragment(), CrudView {

    var tanggall = "000000"
    private lateinit var presenter : Presenter
    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_booking, container, false)
        presenter = Presenter(this)
        presenter.getSaldo()
        (activity as AppCompatActivity).supportActionBar?.title = "Booking"

        val spinner = view.findViewById(R.id.spinAwal) as Spinner
        val adapter = ArrayAdapter.createFromResource(activity as AppCompatActivity, R.array.stasiun, android.R.layout.simple_spinner_item)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter

        val spinnerr = view.findViewById(R.id.spinTujuan) as Spinner
        val adapterr = ArrayAdapter.createFromResource(activity as AppCompatActivity, R.array.stasiun, android.R.layout.simple_spinner_item)
        adapterr.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerr.adapter = adapterr


        val darker = (activity as AppCompatActivity).getColor(R.color.darker)
        val lighter = (activity as AppCompatActivity).getColor(R.color.lighter)
        val sekarang = view?.findViewById<LinearLayout>(R.id.sekarang)
        val besok = view?.findViewById<LinearLayout>(R.id.besok)
        val cari = view?.findViewById<LinearLayout>(R.id.cari)

        var isi = 0

        sekarang?.onClick {
            sekarang.backgroundTintList = ColorStateList.valueOf(lighter)
            besok?.backgroundTintList = ColorStateList.valueOf(darker)
            cari?.backgroundTintList = ColorStateList.valueOf(darker)
            val tglSkrg = LocalDate.now()
            val tglToday = DateTimeFormatter.ofPattern("dd MMM yyyy").format(tglSkrg)
            tanggall = tglToday
            isi += 1
        }
        besok?.onClick {
            sekarang?.backgroundTintList = ColorStateList.valueOf(darker)
            besok.backgroundTintList = ColorStateList.valueOf(lighter)
            cari?.backgroundTintList = ColorStateList.valueOf(darker)
            val tglSkrg = LocalDate.now().plusDays(1)
            val tglToday = DateTimeFormatter.ofPattern("dd MMM yyyy").format(tglSkrg)
            tanggall = tglToday
            isi += 1
        }
        cari?.onClick {
            sekarang?.backgroundTintList = ColorStateList.valueOf(darker)
            besok?.backgroundTintList = ColorStateList.valueOf(darker)
            cari.backgroundTintList = ColorStateList.valueOf(lighter)
            tanggal.visibility = View.VISIBLE
            startTanggal(view)
            isi += 1
        }

            val btnCari = view.findViewById<Button>(R.id.btnCari)
            btnCari.onClick {
                if (isi > 0) {
                activity?.let {
                    val stasiunAwal = spinner.selectedItem.toString()
                    val stasiunTujuan = spinnerr.selectedItem.toString()
                    val berangkat = tanggall
                    val saldo = txtSaldo.text.toString()
                    val intent = Intent(activity, BookActivity::class.java)
                    intent.putExtra("stAwal", stasiunAwal)
                    intent.putExtra("stTujuan", stasiunTujuan)
                    intent.putExtra("tglBerangkat", berangkat)
                    intent.putExtra("saldo", saldo)
                    (activity as AppCompatActivity).startActivity(intent)
                }
            }
        }

        changeHari(view)
        changeTaggalSekarang(view)
        changeTanggalBesok(view)
        changeBulanSekarang(view)
        changeBulanBesok(view)
        return view
    }

    private fun startTanggal(view: View?) {
        val calender: Calendar = Calendar.getInstance()
        val datePicker = view?.findViewById<DatePicker>(R.id.datePicker)
        val gambar = view?.findViewById<ImageView>(R.id.gambarTanggal)
        val hasil = view?.findViewById<TextView>(R.id.hasilTanggal)
        val todayy = Calendar.getInstance()
        datePicker?.datePicker?.minDate = calender.timeInMillis
        datePicker?.init(
            todayy.get(Calendar.YEAR), todayy.get(Calendar.MONTH),
            todayy.get(Calendar.DAY_OF_MONTH)
        ) { view, year, month, day ->
            val month = month + 1
            val msg = "$day-$month-$year"
            tanggal?.visibility = View.GONE
            gambar?.visibility = View.GONE
            hasil?.visibility = View.VISIBLE
            returnInit(msg)
        }
    }

    private fun returnInit(msg: String) {
        val formater = DateTimeFormatter.ofPattern("d-MM-yyyy")
        val date = formater.parse(msg)
        val dayformat = DateTimeFormatter.ofPattern("dd MMM yyyy").format(date)
        val hasil = view?.findViewById<TextView>(R.id.hasilTanggal)
        tanggall = dayformat
        hasil?.text = dayformat
    }

    private fun changeHari(view: View?) {
        val calender : Calendar = Calendar.getInstance()
        val day = calender.get(Calendar.DAY_OF_WEEK)
        val dayTomorow = calender.get(Calendar.DAY_OF_WEEK).plus(1)
        val hari = view?.findViewById<TextView>(R.id.txtHariIni)
        val hariBesok = view?.findViewById<TextView>(R.id.txtHariBesok)
        when (day) {
            Calendar.SUNDAY -> hari?.text = "Minggu"
            Calendar.MONDAY -> hari?.text = "Senin"
            Calendar.TUESDAY -> hari?.text = "Selasa"
            Calendar.WEDNESDAY -> hari?.text = "Rabu"
            Calendar.THURSDAY -> hari?.text = "Kamis"
            Calendar.FRIDAY -> hari?.text = "Jumat"
            Calendar.SATURDAY -> hari?.text = "Sabtu"
        }
        when (dayTomorow) {
            Calendar.SUNDAY -> hariBesok?.text = "Minggu"
            Calendar.MONDAY -> hariBesok?.text = "Senin"
            Calendar.TUESDAY -> hariBesok?.text = "Selasa"
            Calendar.WEDNESDAY -> hariBesok?.text = "Rabu"
            Calendar.THURSDAY -> hariBesok?.text = "Kamis"
            Calendar.FRIDAY -> hariBesok?.text = "Jumat"
            Calendar.SATURDAY -> hariBesok?.text = "Sabtu"
        }
    }

    private fun changeBulanBesok(view: View?) {
        val tomorow = LocalDate.now().plusDays(1)
        val dayformat = DateTimeFormatter.ofPattern("MMM").format(tomorow)
        val bulanBesok = view?.findViewById<TextView>(R.id.monthTomorow)
        bulanBesok?.text = dayformat
    }

    private fun changeBulanSekarang(view: View?) {
        val today = LocalDate.now()
        val todayformat = DateTimeFormatter.ofPattern("MMM").format(today)
        val bulanSekarang = view?.findViewById<TextView>(R.id.sekarangBulan)
        bulanSekarang?.text = todayformat
    }

    private fun changeTanggalBesok(view: View?) {
        val tglBsok = LocalDate.now().plusDays(1)
        val bskToday = DateTimeFormatter.ofPattern("dd").format(tglBsok)
        val tglBesok = view?.findViewById<TextView>(R.id.besokTaggal)
        tglBesok?.text = bskToday
    }

    private fun changeTaggalSekarang(view: View?) {
        val tglSkrg = LocalDate.now()
        val tglToday = DateTimeFormatter.ofPattern("dd").format(tglSkrg)
        val tglSekarang = view?.findViewById<TextView>(R.id.sekarangHari)
        tglSekarang?.text = tglToday
    }

    companion object {
        fun newInstance(): FragmentBooking{
            val fragment = FragmentBooking()
            val args = Bundle()
            fragment.arguments = args
            return fragment
        }
    }

    override fun onSuccessGet(data: List<DataItem>?) {
    }

    override fun onFailedGet(msg: String) {
    }

    override fun onSaldoGet(data: List<DataSaldo>?) {
        onBind(data?.get(0))
    }

    private fun onBind(get: DataSaldo?) {
        txtSaldo.text = get?.saldo
    }

    override fun onFailedSaldo(msg: String) {
        Toast.makeText(TiketActivity(), msg, Toast.LENGTH_SHORT).show()
        Toast.makeText(TiketActivity(), "gagal", Toast.LENGTH_SHORT).show()
    }

    override fun successAdd(msg: String) {
    }

    override fun errorAdd(msg: String) {
    }

    override fun onSuccessUpdate(msg: String) {
    }

    override fun onErrorUpdate(msg: String) {
    }
}