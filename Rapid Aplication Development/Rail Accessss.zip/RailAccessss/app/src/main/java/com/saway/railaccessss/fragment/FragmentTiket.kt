package com.saway.railaccessss.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import com.saway.railaccessss.R
import com.saway.railaccessss.adapter.DataAdapter
import com.saway.railaccessss.model.DataItem
import com.saway.railaccessss.model.DataSaldo
import com.saway.railaccessss.presenter.CrudView
import com.saway.railaccessss.presenter.Presenter
import kotlinx.android.synthetic.main.fragment_tiket.*

class FragmentTiket : Fragment(), CrudView {

    private lateinit var presenter: Presenter
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        presenter = Presenter(this)
        presenter.getData()
        (activity as AppCompatActivity).supportActionBar?.title = "Tiket"
        return inflater.inflate(R.layout.fragment_tiket, container, false)
    }

    companion object {
        fun newInstance(): FragmentTiket{
            val fragment = FragmentTiket()
            val args = Bundle()
            fragment.arguments = args
            return fragment
        }
    }

    override fun onSuccessGet(data: List<DataItem>?) {
        rvCategory.adapter = DataAdapter(data)
    }

    override fun onFailedGet(msg: String) {
    }

    override fun onSaldoGet(data: List<DataSaldo>?) {
        TODO("Not yet implemented")
    }

    override fun onFailedSaldo(msg: String) {
    }

    override fun successAdd(msg: String) {
    }

    override fun errorAdd(msg: String) {
    }

    override fun onSuccessUpdate(msg: String) {
    }

    override fun onErrorUpdate(msg: String) {
    }
}