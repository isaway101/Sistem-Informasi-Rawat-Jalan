package com.saway.railaccessss.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class DataItem: Serializable {
    @field:SerializedName("id")
    val id : String? = null

    @field:SerializedName("kode_booking")
    val kode_booking : String? = null

    @field:SerializedName("stasiun_awal")
    val stasiun_awal : String? = null

    @field:SerializedName("stasiun_tujuan")
    val stasiun_tujuan : String? = null

    @field:SerializedName("tgl_berangkat")
    val tgl_berangkat : String? = null

    @field:SerializedName("tgl_sampai")
    val tgl_sampai : String? = null

    @field:SerializedName("jam_berangkat")
    val jam_berangkat : String? = null

    @field:SerializedName("jam_sampai")
    val jam_sampai : String? = null

    @field:SerializedName("kereta")
    val kereta : String? = null
}