package com.saway.railaccessss.network

import com.saway.railaccessss.model.ResultStatus
import com.saway.railaccessss.model.ResultData
import com.saway.railaccessss.model.ResultSaldo
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.POST

object NetworkConfig {
    fun getInterceptor() : OkHttpClient {
        val logging = HttpLoggingInterceptor()
        logging.level = HttpLoggingInterceptor.Level.BODY

        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor(logging)
            .build()

        return okHttpClient
    }

    //Retrofit

    fun getRetrofit(): Retrofit {
        return Retrofit.Builder()
            .baseUrl("http://192.168.50.109/urraa/index.php/ServerApi/")
            .client(getInterceptor())
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    fun getService() = getRetrofit().create(DataService::class.java)
}
interface DataService{

    @FormUrlEncoded
    @POST("addData")
    fun addStaff(@Field("kode_booking") kode_booking : String,
                 @Field("stasiun_awal") stasiun_awal : String,
                 @Field("stasiun_tujuan") stasiun_tujuan : String,
                 @Field("tgl_berangkat") tgl_berangkat : String,
                 @Field("tgl_sampai") tgl_sampai : String,
                 @Field("jam_berangkat") jam_berangkat : String,
                 @Field("jam_sampai") jam_sampai : String,
                 @Field("kereta") kereta : String) : Call<ResultStatus>

    @GET("getData")
    fun getData() : Call<ResultData>

    @GET("getSaldo")
    fun getSaldo() : Call<ResultSaldo>

    @FormUrlEncoded
    @POST("updateData")
    fun updateData(@Field("id") id: String,
                    @Field("saldo") saldo: String) : Call<ResultStatus>
}