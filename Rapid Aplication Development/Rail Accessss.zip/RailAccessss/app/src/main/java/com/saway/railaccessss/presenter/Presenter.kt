package com.saway.railaccessss.presenter

import android.util.Log
import com.saway.railaccessss.model.ResultData
import com.saway.railaccessss.model.ResultSaldo
import com.saway.railaccessss.model.ResultStatus
import com.saway.railaccessss.network.NetworkConfig
import retrofit2.Call
import retrofit2.Response

class Presenter (val crudView: CrudView) {
    fun getData(){
        NetworkConfig.getService().getData()
            .enqueue(object : retrofit2.Callback<ResultData>{
                override fun onFailure(call: Call<ResultData>, t: Throwable) {
                    crudView.onFailedGet(t.localizedMessage)
                    Log.d("Error", "Error Data")
                }

                override fun onResponse(call: Call<ResultData>, response: Response<ResultData>) {
                    if(response.isSuccessful){
                        val status = response.body()?.status
                        if (status == 200){
                            val data = response.body()?.data
                            crudView.onSuccessGet(data)
                        } else{
                            crudView.onFailedGet("Error $status")
                        }
                    }
                }

            })
    }

    fun getSaldo(){
        NetworkConfig.getService().getSaldo()
            .enqueue(object : retrofit2.Callback<ResultSaldo>{

                override fun onFailure(call: Call<ResultSaldo>, t: Throwable) {
                    crudView.onFailedGet(t.localizedMessage)
                    Log.d("Error", "Error Data")
                }

                override fun onResponse(call: Call<ResultSaldo>, response: Response<ResultSaldo>) {
                    if(response.isSuccessful){
                        val status = response.body()?.status
                        if (status == 200){
                            val saldo = response.body()?.saldo
                            crudView.onSaldoGet(saldo)
                        } else{
                            crudView.onFailedSaldo("Error $status")
                        }
                    }
                }

            })
    }

    fun addData(kode_booking : String, stasiun_awal : String, stasiun_tujuan : String, tgl_berangkat : String, tgl_sampai : String, jam_berangkat : String, jam_sampai : String, kereta : String){
        NetworkConfig.getService()
            .addStaff(kode_booking, stasiun_awal, stasiun_tujuan, tgl_berangkat, tgl_sampai, jam_berangkat, jam_sampai, kereta)
            .enqueue(object : retrofit2.Callback<ResultStatus>{
                override fun onFailure(call: Call<ResultStatus>, t: Throwable) {
                    crudView.errorAdd(t.localizedMessage)
                }

                override fun onResponse(call: Call<ResultStatus>, response: Response<ResultStatus>) {
                    if (response.isSuccessful && response.body()?.status == 200) {
                        crudView.successAdd(response.body()?.pesan ?: "")
                    }else {
                        crudView.errorAdd(response.body()?.pesan ?: "")
                    }
                }

            })
    }

    fun updateData(id: String, saldo: String){
        NetworkConfig.getService()
            .updateData(id, saldo)
            .enqueue(object : retrofit2.Callback<ResultStatus>{
                override fun onFailure(call: Call<ResultStatus>, t: Throwable) {
                    crudView.onErrorUpdate(t.localizedMessage)
                }

                override fun onResponse(call: Call<ResultStatus>, response: Response<ResultStatus>) {
                    if (response.isSuccessful && response.body()?.status == 200){
                        crudView.onSuccessUpdate(response.body()?.pesan ?: "")
                    }else{
                        crudView.onErrorUpdate(response.body()?.pesan ?: "")
                    }

                }

            })
    }

}