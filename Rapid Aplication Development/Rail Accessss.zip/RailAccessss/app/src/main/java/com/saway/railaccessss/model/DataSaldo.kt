package com.saway.railaccessss.model

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class DataSaldo: Serializable {
    @field:SerializedName("id")
    val id : String? = null

    @field:SerializedName("saldo")
    val saldo: String? = null
}