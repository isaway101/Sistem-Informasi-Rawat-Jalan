package com.saway.railaccessss.model

import com.google.gson.annotations.SerializedName

data class ResultData (
    @field:SerializedName("pesan")
    val pesan : String? = null,

    @field:SerializedName("data")
    val data : List<DataItem>? = null,

    @field:SerializedName("status")
    val status : Int? = null
)