package com.saway.railaccessss

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.FrameLayout
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.saway.railaccessss.fragment.FragmentAkun
import com.saway.railaccessss.fragment.FragmentBooking
import com.saway.railaccessss.fragment.FragmentHistory
import com.saway.railaccessss.fragment.FragmentTiket
import kotlinx.android.synthetic.main.activity_tiket.*

class TiketActivity : AppCompatActivity() {
    private var content: FrameLayout? = null

    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.booking -> {
                val fragment = FragmentBooking.newInstance()
                addFragment(fragment)
                return@OnNavigationItemSelectedListener true
            }
            R.id.tiket-> {
                val fragment = FragmentTiket()
                addFragment(fragment)
                return@OnNavigationItemSelectedListener true
            }
            R.id.riwayat-> {
                val fragment = FragmentHistory()
                addFragment(fragment)
                return@OnNavigationItemSelectedListener true
            }
            R.id.akun-> {
                val fragment = FragmentAkun()
                addFragment(fragment)
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    private fun addFragment(fragment: Fragment) {
        supportFragmentManager
            .beginTransaction()
            .setCustomAnimations(R.anim.design_bottom_sheet_slide_in, R.anim.design_bottom_sheet_slide_out)
            .replace(R.id.content, fragment, fragment.javaClass.getSimpleName())
            .commit()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tiket)
        bottom_navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
        val fragment = FragmentBooking.newInstance()
        addFragment(fragment)

    }
}