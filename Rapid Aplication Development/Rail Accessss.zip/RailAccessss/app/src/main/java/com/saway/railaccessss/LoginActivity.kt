package com.saway.railaccessss

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.StrictMode
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.widget.*
import androidx.core.view.ViewCompat
import org.jetbrains.anko.ctx
import org.jetbrains.anko.find
import java.sql.Connection
import java.sql.DriverManager
import java.sql.ResultSet
import java.sql.SQLException

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        makeStatusBarTransparent()
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.container)) { _, insets ->
            insets.consumeSystemWindowInsets()
        }

        forgot()
        login()
    }

    private fun login() {
        val button = findViewById<Button>(R.id.btnSignin)
        val txtEmail = findViewById<EditText>(R.id.txtEmail)
        val txtPass = findViewById<EditText>(R.id.txtPassword)
        val email = "user@gmail.com"
        val password = "pasword123"
        button.setOnClickListener {
            var valid = true
            if (txtEmail.text.toString()=="") {
                valid = false
                txtEmail.setError("Harap masukkan Email")
            }
            if (txtPass.text.toString()=="") {
                valid = false
                txtPass.setError("Harap masukkan password")
            }
            if (valid) {
                if (email == (txtEmail.text.toString()) && password == (txtPass.text.toString())) {
                    val intent = Intent(this, TiketActivity::class.java)
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "username atau password salah", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun forgot() {
        val lupa = findViewById<TextView>(R.id.txtForgot)
        val email = findViewById<EditText>(R.id.txtEmail)
        lupa.setOnClickListener {
            if (email.text.toString() == "") {
                Toast.makeText(this, "Email tidak boleh kosong", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Form reset password dikirim ke email anda", Toast.LENGTH_LONG).show()
            }
        }
    }
}