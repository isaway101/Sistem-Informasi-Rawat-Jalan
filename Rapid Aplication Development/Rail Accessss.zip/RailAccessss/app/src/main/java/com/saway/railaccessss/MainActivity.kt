package com.saway.railaccessss

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import androidx.core.view.ViewCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val timer = object : CountDownTimer(2000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                setContentView(R.layout.activity_main)

                makeStatusBarTransparent()
                ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.container)) { _, insets ->
                    insets.consumeSystemWindowInsets()
                }
            }

            override fun onFinish() {
                move()
            }
        }
        timer.start()
    }

    private fun move() {
        val intent = Intent(this, LoginActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)
    }
}