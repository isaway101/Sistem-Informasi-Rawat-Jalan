package com.saway.railaccessss.adapter

import android.content.ContentValues.TAG
import android.graphics.Bitmap
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.WriterException
import com.saway.railaccessss.model.DataItem
import com.saway.railaccessss.R
import kotlinx.android.synthetic.main.item_data.view.*

class DataAdapter(val data: List<DataItem>?) : RecyclerView.Adapter<DataAdapter.MyHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_data,parent,false)
        return MyHolder(view)
    }

    override fun getItemCount() = data?.size ?: 0

    override fun onBindViewHolder(holder: MyHolder, position: Int) {
        holder.onBind(data?.get(position))
    }

    class MyHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun onBind(get: DataItem?) {
            itemView.txtKereta1.text = get?.kereta
            itemView.txtHarga1.text = get?.kode_booking
            itemView.txtAwal.text = get?.stasiun_awal
            itemView.txtAkhir.text = get?.stasiun_tujuan
            itemView.txtWaktuBerangkat1.text = get?.jam_berangkat
            itemView.txtWaktuSampai.text = get?.jam_sampai
            itemView.tglBerangkat.text = get?.tgl_berangkat
            itemView.txtTglSampai1.text = get?.tgl_sampai
            val bitmap = generateQRCode(get?.kode_booking.toString())
            itemView.qr.setImageBitmap(bitmap)
        }

        private fun generateQRCode(text: String): Bitmap {
            val width = 500
            val height = 500
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val codeWriter = MultiFormatWriter()
            try {
                val bitMatrix = codeWriter.encode(text, BarcodeFormat.QR_CODE, width, height)
                for (x in 0 until width) {
                    for (y in 0 until height) {
                        bitmap.setPixel(x, y, if (bitMatrix[x, y]) Color.BLACK else Color.WHITE)
                    }
                }
            } catch (e: WriterException) {
                Log.d(TAG, "generateQRCode: ${e.message}")
            }
            return bitmap
        }
    }
}