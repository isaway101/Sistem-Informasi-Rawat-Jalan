package com.saway.railaccessss

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.saway.railaccessss.model.DataItem
import com.saway.railaccessss.model.DataSaldo
import com.saway.railaccessss.presenter.CrudView
import com.saway.railaccessss.presenter.Presenter
import org.jetbrains.anko.startActivity
import java.text.SimpleDateFormat
import java.util.*

class BookActivity : AppCompatActivity(), CrudView {
    private lateinit var presenter: Presenter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_book)
        this.supportActionBar?.title = "Booking"
        presenter = Presenter(this)
        val stAw = intent.getStringExtra("stAwal")
        val stAwal = stAw.toString()
        val stTuju = intent.getStringExtra("stTujuan")
        val stTujuan = stTuju.toString()
        val tglB = intent.getStringExtra("tglBerangkat")
        val tglBerangkat = tglB.toString()
        val tagl = findViewById<TextView>(R.id.txtTanggal)
        tagl.text = tglBerangkat
        val sald = intent.getStringExtra("saldo")
        val saldo = sald.toString()
        val awal1 = findViewById<TextView>(R.id.txtStasiunAwal1)
        val akhir1 = findViewById<TextView>(R.id.txtStasiunTujuan1)
        val awal2 = findViewById<TextView>(R.id.txtAwal)
        val akhir2 = findViewById<TextView>(R.id.txtAkhir)
        val awal3 = findViewById<TextView>(R.id.txtAwal2)
        val akhir3 = findViewById<TextView>(R.id.txtAkhir2)
        val awal4 = findViewById<TextView>(R.id.txtAwal3)
        val akhir4 = findViewById<TextView>(R.id.txtAkhir3)
        val tglBesok = findViewById<TextView>(R.id.txtTglSampai1)
        val tglSekarang = findViewById<TextView>(R.id.txtTglBerangkat1)
        val tglBesok2 = findViewById<TextView>(R.id.txtTglSampai2)
        val tglSekarang2 = findViewById<TextView>(R.id.txtTglBerangkat2)
        val tglBesok3 = findViewById<TextView>(R.id.txtTglSampai3)
        val tglSekarang3 = findViewById<TextView>(R.id.txtTglBerangkat3)
        awal1.text = stAwal
        akhir1.text = stTujuan
        awal2.text = stAwal
        akhir2.text = stTujuan
        awal3.text = stAwal
        akhir3.text = stTujuan
        awal4.text = stAwal
        akhir4.text = stTujuan
        var dt = tglBerangkat
        val sdf = SimpleDateFormat("dd MMM yyyy")
        val c = Calendar.getInstance()
        c.time = sdf.parse(dt)
        c.add(Calendar.DATE, 1)
        dt = sdf.format(c.time)
        tglSekarang.text = tglBerangkat
        tglBesok.text = dt
        tglBesok2.text = tglBerangkat
        tglSekarang2.text = tglBerangkat
        tglSekarang3.text = tglBerangkat
        tglBesok3.text = dt
        val beli1 = findViewById<Button>(R.id.beli1)
        val beli2 = findViewById<Button>(R.id.beli2)
        val beli3 = findViewById<Button>(R.id.beli3)

        beli1.setOnClickListener{

            val nama = findViewById<TextView>(R.id.txtKereta1)
            val price = findViewById<TextView>(R.id.txtHarga1)
            val jamBe = findViewById<TextView>(R.id.txtWaktuBerangkat1)
            val jamSa = findViewById<TextView>(R.id.txtWaktuSampai)
            val kereta = nama.text.toString()
            val harga = price.text.toString()
            val jamBerangkat = jamBe.text.toString()
            val jamSampai = jamSa.text.toString()

            val sb = StringBuilder (6)
            val alphabet = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890"
            val rand = Random()
            for (i in 0 until sb.capacity()) {
                val index = rand.nextInt(alphabet.length)
                sb.append((alphabet[index]))
            }
            val kodeBooking = sb.toString()

            val sisa = saldo.toInt() - harga.toInt()
            if (sisa >= 0) {
                presenter.updateData("1", sisa.toString())
                presenter.addData(kodeBooking, stAwal, stTujuan, tglBerangkat, dt, jamBerangkat, jamSampai, kereta)
            }
        }

        beli2.setOnClickListener{

            val nama = findViewById<TextView>(R.id.txtKereta2)
            val price = findViewById<TextView>(R.id.txtHarga2)
            val jamBe = findViewById<TextView>(R.id.txtWaktuBerangkat2)
            val jamSa = findViewById<TextView>(R.id.txtWaktuSampai2)
            val kereta = nama.text.toString()
            val harga = price.text.toString()
            val jamBerangkat = jamBe.text.toString()
            val jamSampai = jamSa.text.toString()

            val sb = StringBuilder (6)
            val alphabet = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890"
            val rand = Random()
            for (i in 0 until sb.capacity()) {
                val index = rand.nextInt(alphabet.length)
                sb.append((alphabet[index]))
            }
            val kodeBooking = sb.toString()

            val sisa = saldo.toInt() - harga.toInt()
            if (sisa >= 0) {
                presenter.updateData("1", sisa.toString())
                presenter.addData(kodeBooking, stAwal, stTujuan, tglBerangkat, tglBerangkat, jamBerangkat, jamSampai, kereta)
            }
        }

        beli3.setOnClickListener{

            val nama = findViewById<TextView>(R.id.txtKereta3)
            val price = findViewById<TextView>(R.id.txtHarga3)
            val jamBe = findViewById<TextView>(R.id.txtWaktuBerangkat3)
            val jamSa = findViewById<TextView>(R.id.txtWaktuSampai3)
            val kereta = nama.text.toString()
            val harga = price.text.toString()
            val jamBerangkat = jamBe.text.toString()
            val jamSampai = jamSa.text.toString()

            val sb = StringBuilder (6)
            val alphabet = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890"
            val rand = Random()
            for (i in 0 until sb.capacity()) {
                val index = rand.nextInt(alphabet.length)
                sb.append((alphabet[index]))
            }
            val kodeBooking = sb.toString()

            val sisa = saldo.toInt() - harga.toInt()
            if (sisa >= 0) {
                presenter.updateData("1", sisa.toString())
                presenter.addData(kodeBooking, stAwal, stTujuan, tglBerangkat, dt, jamBerangkat, jamSampai, kereta)
            }
        }
    }

    override fun onSuccessGet(data: List<DataItem>?) {
        TODO("Not yet implemented")
    }

    override fun onFailedGet(msg: String) {
        TODO("Not yet implemented")
    }

    override fun onSaldoGet(data: List<DataSaldo>?) {
        TODO("Not yet implemented")
    }

    override fun onFailedSaldo(msg: String) {
        TODO("Not yet implemented")
    }

    override fun successAdd(msg: String) {
        val intent = Intent(this, TiketActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)
    }

    override fun errorAdd(msg: String) {
        TODO("Not yet implemented")
    }

    override fun onSuccessUpdate(msg: String) {

    }

    override fun onErrorUpdate(msg: String) {
        TODO("Not yet implemented")
    }
}
